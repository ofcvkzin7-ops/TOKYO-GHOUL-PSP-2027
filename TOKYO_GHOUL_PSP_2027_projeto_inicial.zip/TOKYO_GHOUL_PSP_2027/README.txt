TOKYO GHOUL: PSP 2027 - projeto inicial

IMPORTANTE:
- Este ZIP contem codigo-fonte, nao e um jogo pronto.
- Ainda nao e ISO/CSO nem EBOOT.PBP.
- O codigo atual e somente uma tela de teste para PSP.
- Nao inclui personagens, modelos 3D, musicas ou arquivos oficiais de Tokyo Ghoul.

Para compilar:
1. Instale e configure o PSPDEV/PSPSDK em um ambiente compativel.
2. Abra o terminal nesta pasta.
3. Execute: make
4. O SDK devera gerar EBOOT.PBP.
5. Copie a pasta gerada para PSP/GAME/TOKYO_GHOUL_PSP_2027/ no cartao/armazenamento usado pelo PPSSPP.

O Termux ARMv7 mostrado anteriormente nao confirma suporte ao toolchain PSPDEV.
Precisamos resolver a compilacao em ambiente compativel antes de gerar um EBOOT.PBP.
