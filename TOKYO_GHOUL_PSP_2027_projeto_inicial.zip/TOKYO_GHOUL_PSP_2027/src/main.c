#include <pspkernel.h>
#include <pspdebug.h>
#include <pspctrl.h>

PSP_MODULE_INFO("TOKYO_GHOUL_PSP_2027", 0, 1, 0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER);

int main(void) {
    pspDebugScreenInit();
    sceCtrlSetSamplingCycle(0);
    sceCtrlSetSamplingMode(PSP_CTRL_MODE_ANALOG);

    pspDebugScreenSetTextColor(0xFFFFFFFF);
    pspDebugScreenPrintf("TOKYO GHOUL: PSP 2027\n");
    pspDebugScreenPrintf("----------------------\n\n");
    pspDebugScreenPrintf("Projeto inicial de homebrew PSP.\n");
    pspDebugScreenPrintf("Idioma: Portugues (Brasil)\n\n");
    pspDebugScreenPrintf("Controles:\n");
    pspDebugScreenPrintf("X: confirmar (proxima etapa)\n");
    pspDebugScreenPrintf("START: sair\n\n");
    pspDebugScreenPrintf("Esta versao e apenas um teste de inicializacao.\n");
    pspDebugScreenPrintf("Ainda nao contem modelos 3D ou personagens.\n");

    SceCtrlData pad;
    while (1) {
        sceCtrlReadBufferPositive(&pad, 1);
        if (pad.Buttons & PSP_CTRL_START) break;
        sceKernelDelayThread(10000);
    }

    sceKernelExitGame();
    return 0;
}
