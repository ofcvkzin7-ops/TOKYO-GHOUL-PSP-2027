# TOKYO GHOUL: PSP 2027 — projeto inicial

Projeto inicial de homebrew para PSP, em português do Brasil.

**Importante:** este ZIP é apenas uma base técnica com uma cena de teste. Não contém o jogo completo, personagens/modelos, vozes, músicas, fases ou uma ISO comercial. Esses conteúdos precisam ser criados ou licenciados separadamente.

## Compilar

O fluxo do GitHub Actions usa a imagem de desenvolvimento PSPDEV e tenta gerar `EBOOT.PBP`.
Depois de enviar os arquivos ao GitHub, abra **Actions**, execute o workflow e baixe o artefato `tokyo-ghoul-psp`.

## Controles da cena de teste

- Analógico: mover o quadrado pela tela
- START: sair

## Estrutura

- `src/` código C
- `assets/` recursos do jogo
- `models/` modelos 3D (ainda vazio)
- `textures/` texturas (ainda vazio)
- `audio/` áudio (ainda vazio)
