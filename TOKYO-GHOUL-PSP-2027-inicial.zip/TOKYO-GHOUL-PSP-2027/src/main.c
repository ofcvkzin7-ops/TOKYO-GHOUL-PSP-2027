#include <pspkernel.h>
#include <pspdebug.h>
#include <pspdisplay.h>
#include <pspctrl.h>

PSP_MODULE_INFO("Tokyo Ghoul PSP 2027", 0, 1, 0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER);

int main(void) {
    SceCtrlData pad;
    int x = 240, y = 136;

    pspDebugScreenInit();
    sceCtrlSetSamplingCycle(0);
    sceCtrlSetSamplingMode(PSP_CTRL_MODE_ANALOG);

    while (1) {
        sceCtrlReadBufferPositive(&pad, 1);
        if (pad.Buttons & PSP_CTRL_START) break;

        if (pad.Lx < 110) x -= 2;
        if (pad.Lx > 145) x += 2;
        if (pad.Ly < 110) y -= 2;
        if (pad.Ly > 145) y += 2;

        if (x < 0) x = 0;
        if (x > 470) x = 470;
        if (y < 0) y = 0;
        if (y > 260) y = 260;

        pspDebugScreenSetXY(0, 0);
        pspDebugScreenPrintf("TOKYO GHOUL: PSP 2027\\n");
        pspDebugScreenPrintf("Prototipo inicial - Portugues BR\\n");
        pspDebugScreenPrintf("Analógico: mover | START: sair\\n");
        pspDebugScreenSetXY(x / 8, y / 8);
        pspDebugScreenPrintf("[]");
        sceDisplayWaitVblankStart();
    }

    sceKernelExitGame();
    return 0;
}
